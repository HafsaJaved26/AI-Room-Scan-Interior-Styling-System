import cv2
import os
import numpy as np
from glob import glob

print("="*60)
print("MEMBER 9 - VIDEO GENERATOR ")
print("="*60)

# ===== CONFIGURATION =====
input_folder = "inputs"
redesign_folder = "redesigned_images"
output_file = "final_video_.mp4"  

# ===== GET INPUT IMAGE =====
input_images = glob(os.path.join(input_folder, "*.png")) + glob(os.path.join(input_folder, "*.jpg"))
if len(input_images) == 0:
    print("❌ No input images found!")
    exit()

input_path = input_images[0]
print(f"\n✅ Input: {os.path.basename(input_path)}")

# ===== GET REDESIGN IMAGES =====
redesign_images = sorted(glob(os.path.join(redesign_folder, "*.png")) + glob(os.path.join(redesign_folder, "*.jpg")))

if len(redesign_images) < 3:
    print("❌ Need at least 3 redesign images!")
    exit()

print(f"\n✅ First 3 redesign images:")
for i in range(3):
    print(f"   {i+1}. {os.path.basename(redesign_images[i])}")

# ===== ASSUME ORDER: 1=Minimal, 2=Modern, 3=Luxury =====
redesign_paths = {
    "Minimal": redesign_images[0],
    "Modern": redesign_images[1],
    "Luxury": redesign_images[2]
}

# ===== VIDEO SETTINGS - WhatsApp Compatible =====
fps = 25  # WhatsApp prefers 25fps
seconds_per_style = 3
width, height = 1280, 720  # 720p HD (WhatsApp friendly)

# WhatsApp compatible codec
fourcc = cv2.VideoWriter_fourcc(*'avc1')  # H.264 codec

# Try different codecs if avc1 doesn't work
video = None
try:
    video = cv2.VideoWriter(output_file, fourcc, fps, (width, height))
    if not video.isOpened():
        # Fallback to mp4v
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        video = cv2.VideoWriter(output_file, fourcc, fps, (width, height))
except:
    # Final fallback
    fourcc = cv2.VideoWriter_fourcc(*'X264')
    video = cv2.VideoWriter(output_file, fourcc, fps, (width, height))

if not video.isOpened():
    print("❌ Could not create video file!")
    exit()

# ===== LOAD AND PREPARE IMAGES =====
before = cv2.imread(input_path)
before = cv2.resize(before, (width//2, height))  # Left half width

styles = ["Minimal", "Modern", "Luxury"]

print(f"\n🎬 Creating WhatsApp-compatible video...")
print(f"   Resolution: {width}x{height}")
print(f"   FPS: {fps}")
print(f"   Duration: {len(styles) * seconds_per_style} seconds")
print("-"*40)

for style_name in styles:
    print(f"\n📹 {style_name}")
    
    # Load redesign image
    redesign_path = redesign_paths[style_name]
    after = cv2.imread(redesign_path)
    after = cv2.resize(after, (width//2, height))
    
    # Create side-by-side frame
    frame = np.hstack((before, after))
    
    # Add top bar
    cv2.rectangle(frame, (0, 0), (width, 70), (0, 0, 0), -1)
    
    # Add text
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(frame, "BEFORE", (width//4 - 40, 45), font, 1, (255, 255, 255), 2)
    cv2.putText(frame, f"AFTER - {style_name.upper()}", (width*3//4 - 100, 45), font, 1, (255, 255, 255), 2)
    
    # Add dividing line
    cv2.line(frame, (width//2, 0), (width//2, height), (255, 255, 255), 3)
    
    # Add bottom timestamp (optional)
    time_text = f"{style_name} Style - 3 sec"
    cv2.putText(frame, time_text, (width//2 - 80, height-20), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)
    
    # Write frames
    for _ in range(fps * seconds_per_style):
        video.write(frame)

video.release()

# ===== VERIFY AND CONVERT IF NEEDED =====
if os.path.exists(output_file):
    size_mb = os.path.getsize(output_file) / (1024 * 1024)
    
    print("\n" + "="*60)
    print("✅ VIDEO CREATED SUCCESSFULLY!")
    print("="*60)
    print(f"📁 File: {os.path.abspath(output_file)}")
    print(f"📊 Size: {size_mb:.1f} MB")
    print(f"🎯 Resolution: {width}x{height}")
    print(f"⏱️ Duration: {len(styles) * seconds_per_style} seconds")
    print("\n📱 WhatsApp Compatible:")
    print("   ✓ H.264 codec")
    print("   ✓ 720p resolution")
    print("   ✓ 25fps")
    print("="*60)
    
    if size_mb > 16:
        print("")
        print("")
else:
    print("❌ Failed to create video!")