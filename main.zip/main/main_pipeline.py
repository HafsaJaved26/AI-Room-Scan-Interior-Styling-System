import argparse
import os
import sys

def run_pipeline():
    parser = argparse.ArgumentParser(description="AI Room Design Pipeline")
    parser.add_argument("--input", type=str, required=True, help="Input video or folder path")
    parser.add_argument("--mode", type=int, default=1, help="Style Mode (1, 2, or 3)")
    parser.add_argument("--prompt", type=str, default="Modern luxury interior", help="Style prompt")

    args = parser.parse_args()

    print(f"🚀 Starting Pipeline with Mode {args.mode}...")

    # Step 1: Run Member 8 Generation (Aapka pichla code)
    print("\n[STEP 1] Generating Redesigned Images...")
    os.system("python member8_generation.py")

    # Step 2: Run Video Generation (Member 9 ka code)
    print("\n[STEP 2] Creating Final Video...")
    os.system("python video_generator.py")

    print("\n✨ PIPELINE COMPLETE! Check 'final_outputs' folder.")

if __name__ == "__main__":
    run_pipeline()




