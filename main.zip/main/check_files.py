import os
import glob

print("--- Checking Folders ---")
depth_files = glob.glob("depth_maps/*.*")
redesign_files = glob.glob("redesigned_images/*.*")

print(f"Total files in depth_maps: {len(depth_files)}")
for f in depth_files: print(f" - {f}")

print(f"\nTotal files in redesigned_images: {len(redesign_files)}")
for f in redesign_files: print(f" - {f}")