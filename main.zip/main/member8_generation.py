import torch
from diffusers import StableDiffusionControlNetPipeline, ControlNetModel, UniPCMultistepScheduler
from PIL import Image
import os, glob, re

# --- CONFIGURATION ---
DEPTH_DIR = "depth_maps"
MASK_DIR = "object_masks"
OUTPUT_DIR = "redesigned_images"

# Is Prompt se results bohot professional ayenge
PROMPT = "Luxury master bedroom, scandinavian minimalist aesthetic, high-quality oak furniture, soft cinematic warm lighting, clean architectural lines, 8k UHD, highly detailed, photorealistic, interior design magazine style"
NEGATIVE_PROMPT = "blurry, low quality, distorted, grainy, messy, extra fingers, dark, gloomy, low resolution"

if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)

print("⏳ Loading High-End Pipeline...")
controlnets = [
    ControlNetModel.from_pretrained("lllyasviel/sd-controlnet-depth", torch_dtype=torch.float32),
    ControlNetModel.from_pretrained("lllyasviel/sd-controlnet-seg", torch_dtype=torch.float32)
]
pipe = StableDiffusionControlNetPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5", controlnet=controlnets, torch_dtype=torch.float32
)
pipe.scheduler = UniPCMultistepScheduler.from_config(pipe.scheduler.config)
pipe.enable_attention_slicing()

# --- PROCESSING ---
depth_files = sorted(glob.glob(os.path.join(DEPTH_DIR, "*.*")))

for depth_path in depth_files:
    num = re.findall(r'\d+', os.path.basename(depth_path))[0]
    mask_matches = glob.glob(os.path.join(MASK_DIR, f"**/*{num}*mask.png"), recursive=True)
    
    if not mask_matches: continue
    
    print(f"🎨 Rendering Ultra-Quality Frame {num}...")
    depth_img = Image.open(depth_path).convert("RGB").resize((512, 512))
    mask_img = Image.open(mask_matches[0]).convert("RGB").resize((512, 512))
    
    # 35-40 steps se blur bilkul khatam ho jata hai
    output = pipe(PROMPT, negative_prompt=NEGATIVE_PROMPT, image=[depth_img, mask_img],
                  num_inference_steps=40, controlnet_conditioning_scale=[1.0, 0.8]).images[0]
    
    output.save(os.path.join(OUTPUT_DIR, f"redesigned_frame_{num}.png"))

print("✅ High-Quality Images Ready!")