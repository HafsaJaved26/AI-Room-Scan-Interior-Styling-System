# Member 5: Generic Style Mode

## Three Fixed Interior Styles -- Modern, Minimal, Luxury

### Overview

This module implements Style Mode 1 -- Generic Style Implementation for
the AI Room Redesign System.

It provides three predefined interior design styles that can be applied
consistently across all generated room frames. The goal of this module
is to ensure visual consistency, structured configuration output, and
smooth integration with the image generation pipeline.

------------------------------------------------------------------------

## Team Member

Hafsa Javed\
Member 5 -- Generic Style Mode\
February 2026

------------------------------------------------------------------------

## Available Styles

**Modern**\
Clean, contemporary design with sleek furniture and neutral tones.

**Minimal**\
Simple, functional spaces with clean lines, natural light, and
clutter-free aesthetics.

**Luxury**\
Elegant interiors featuring premium materials, rich textures, and
sophisticated finishes.

------------------------------------------------------------------------

## Module Responsibilities

-   Provides three fixed predefined interior styles\
-   Generates structured configuration output for the pipeline\
-   Ensures visual consistency using a fixed seed value\
-   Supplies prompts and negative prompts for image generation\
-   Produces organized output files for integration

------------------------------------------------------------------------

## Inputs

-   style_key -- Selected style (modern, minimal, luxury)\
-   num_frames -- Number of frames extracted from Member 1 (video
    processing module)

------------------------------------------------------------------------

## Outputs

The module returns a structured configuration containing:

-   Selected style name\
-   Prompt text\
-   Negative prompt\
-   Fixed seed value (42 for consistency)\
-   Number of frames

It also optionally generates configuration files for integration.

------------------------------------------------------------------------

## Output Files Generated

When executed with output saving enabled, the following files are
created:

-   all_styles.json -- Complete configuration of all three styles\
-   prompts.txt -- Readable file containing all prompts\
-   negative_prompts.txt -- Readable file containing all negative
    prompts

For testing purposes, style-specific configuration files are generated
inside organized folders.

------------------------------------------------------------------------

## Folder Structure

GenericStyle

-   generic_style_mode.py\
-   README.md\
-   outputs
    -   all_styles.json\
    -   prompts.txt\
    -   negative_prompts.txt\


------------------------------------------------------------------------

## Integration with Pipeline

This module integrates between:

-   Member 1 (Input Processing) -- Provides number of frames\
-   Member 8/9 (Image Generation) -- Uses prompt, negative prompt,
    and seed

The fixed seed ensures stylistic consistency across all frames in a
video sequence.

------------------------------------------------------------------------

## System Requirements

-   Python 3.8 or higher\
-   No external libraries required\
-   CPU compatible\
-   Works offline after setup

------------------------------------------------------------------------

## Design Decisions

### Why Fixed Styles?

Using predefined styles ensures:

-   Controlled and predictable output\
-   Faster processing\
-   Clear separation between style modes\
-   Easy integration with the generation pipeline

### Why Fixed Seed (42)?

A fixed seed ensures:

-   Consistent visual style across frames\
-   No random variation between frames\
-   Stable and reproducible outputs

------------------------------------------------------------------------

## Deliverables Status

-   Three fixed styles implemented\
-   Structured configuration output\
-   Pipeline integration ready\
-   No external dependencies\
-   Organized output generation\
-   Fully documented

------------------------------------------------------------------------

## Module Status

This module is complete and ready for integration into the main AI Room
Scan and Interior Styling System pipeline.
